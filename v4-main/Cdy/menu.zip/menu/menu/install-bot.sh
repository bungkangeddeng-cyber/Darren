#!/bin/bash
# Installer bot lama DINONAKTIFKAN: bot lama tidak lagi dipasang dari luar repo. Kelola ripzz-bot-js via m-bot (pm2).
# Menu ini tidak mengunduh/menjalankan kode dari luar repo Darren.
clear
echo "Installer bot lama DINONAKTIFKAN: bot lama tidak lagi dipasang dari luar repo. Kelola ripzz-bot-js via m-bot (pm2)."
echo "Pembaruan/pemasangan hanya lewat installer repo Darren."
read -n 1 -s -r -p "Tekan tombol apa saja untuk kembali ke menu"
menu
